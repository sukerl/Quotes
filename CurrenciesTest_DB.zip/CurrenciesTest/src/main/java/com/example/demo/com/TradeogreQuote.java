package com.example.demo.com;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TradeogreQuote {
	
	BigDecimal initialprice;
	BigDecimal price;
	BigDecimal high;
	BigDecimal low;
	BigDecimal volume;
	BigDecimal bid;
	BigDecimal ask;
	
	public TradeogreQuote() {
		super();
	}

	public BigDecimal getInitialprice() {
		return initialprice;
	}

	public void setInitialprice(BigDecimal initialprice) {
		this.initialprice = initialprice;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public BigDecimal getHigh() {
		return high;
	}

	public void setHigh(BigDecimal high) {
		this.high = high;
	}

	public BigDecimal getLow() {
		return low;
	}

	public void setLow(BigDecimal low) {
		this.low = low;
	}

	public BigDecimal getVolume() {
		return volume;
	}

	public void setVolume(BigDecimal volume) {
		this.volume = volume;
	}

	public BigDecimal getBid() {
		return bid;
	}

	public void setBid(BigDecimal bid) {
		this.bid = bid;
	}

	public BigDecimal getAsk() {
		return ask;
	}

	public void setAsk(BigDecimal ask) {
		this.ask = ask;
	}

	@Override
	public String toString() {
		return "TradeogreQuote [initialprice=" + initialprice + ", price=" + price + ", high=" + high + ", low=" + low
				+ ", volume=" + volume + ", bid=" + bid + ", ask=" + ask + "]";
	}
}
