package com.example.demo;

import java.math.BigDecimal;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.example.demo.com.GenericQuote;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class TradeogreController {

	private static final Logger log = LoggerFactory.getLogger(TradeogreController.class);
	
	private final QuoteRepository QRepository;
	public TradeogreController(QuoteRepository QRepository) {
		this.QRepository = QRepository;
	}

	@Scheduled(cron = "${tradeogre.schedule}")
	public void run() {

		RestTemplateBuilder tradeogreRestTemplateBuilder = new RestTemplateBuilder();
		RestTemplate tradeogreRestTemplate = tradeogreRestTemplateBuilder.build();

		try {
			String jsonString = tradeogreRestTemplate.getForObject("https://tradeogre.com/api/v1/ticker/btc-tube", String.class);
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(jsonString);

			GenericQuote tradeogreQuote = new GenericQuote();

			tradeogreQuote.setExchangeName("Tradeogre");
			tradeogreQuote.setMarketName("btc-tube");
			tradeogreQuote.setPrice(BigDecimal.valueOf(rootNode.path("price").asDouble()));
			tradeogreQuote.setHigh(BigDecimal.valueOf(rootNode.path("high").asDouble()));
			tradeogreQuote.setLow(BigDecimal.valueOf(rootNode.path("low").asDouble()));
			tradeogreQuote.setVolume(BigDecimal.valueOf(rootNode.path("volume").asDouble()));
			tradeogreQuote.setBid(BigDecimal.valueOf(rootNode.path("bid").asDouble()));
			tradeogreQuote.setAsk(BigDecimal.valueOf(rootNode.path("ask").asDouble()));
			tradeogreQuote.setRequestTimestamp(new Timestamp(System.currentTimeMillis()));

			log.info(tradeogreQuote.toString());
			QRepository.save(tradeogreQuote);

		} catch (Exception e) {
			log.error(e.toString());
		}
	}

}
