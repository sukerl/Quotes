package li.bankfrick.informatik.reporting.csdr.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import li.bankfrick.informatik.reporting.csdr.entities.db.mapping.SttlmIntlr_FinInstrm_Mapping;

public interface SttlmIntlr_FinInstrm_Mapping_Repository extends JpaRepository<SttlmIntlr_FinInstrm_Mapping, Integer> {
	

}
