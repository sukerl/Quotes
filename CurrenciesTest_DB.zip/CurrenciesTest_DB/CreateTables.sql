DROP TABLE IF EXISTS Quotes;

CREATE TABLE Quotes (
Quote_ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
ExchangeName VARCHAR(255) NOT NULL,
MarketName VARCHAR(255) NOT NULL,
Price DOUBLE(30,10) SIGNED NOT NULL,
High DOUBLE(30,10) SIGNED NOT NULL,
Low DOUBLE(30,10) SIGNED NOT NULL,
Volume DOUBLE(30,10) SIGNED NOT NULL,
Bid DOUBLE(30,10) SIGNED NOT NULL,
Ask DOUBLE(30,10) SIGNED NOT NULL,
RequestTimestamp TIMESTAMP NOT NULL,
CONSTRAINT unique_content UNIQUE (Quote_ID, ExchangeName, MarketName, Price, High, Low, Volume, Bid, Ask, RequestTimestamp)
);

CREATE OR REPLACE VIEW daten_fuer_excel_grafik (RequestTimestamp, PreisBittrex, PreisTradeogre) AS
SELECT
    `b`.`RequestTimestamp`         AS `RequestTimestamp`,
    format(`b`.`PreisBittrex`,8)   AS `PreisBittrex`,
    format(`t`.`PreisTradeogre`,8) AS `PreisTradeogre`
FROM
    ((
    (
        SELECT
            date_format(`currencies_test`.`quotes`.`RequestTimestamp`,'%d.%m.%Y %H:%i') AS
            `RequestTimestamp`,
            `currencies_test`.`quotes`.`Price` AS `PreisBittrex`
        FROM
            `currencies_test`.`quotes`
        WHERE
            `currencies_test`.`quotes`.`ExchangeName` = 'Bittrex')) `b`
JOIN
    (
        SELECT
            date_format(`currencies_test`.`quotes`.`RequestTimestamp`,'%d.%m.%Y %H:%i') AS
            `RequestTimestamp`,
            `currencies_test`.`quotes`.`Price` AS `PreisTradeogre`
        FROM
            `currencies_test`.`quotes`
        WHERE
            `currencies_test`.`quotes`.`ExchangeName` = 'Tradeogre') `t`
ON
    (
        `b`.`RequestTimestamp` = `t`.`RequestTimestamp`))
GROUP BY
    `b`.`RequestTimestamp`;