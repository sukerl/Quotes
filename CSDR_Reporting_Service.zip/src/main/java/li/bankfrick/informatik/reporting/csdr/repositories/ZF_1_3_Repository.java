package li.bankfrick.informatik.reporting.csdr.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import li.bankfrick.informatik.reporting.csdr.entities.db.excel.ZF_1_3;

public interface ZF_1_3_Repository extends JpaRepository<ZF_1_3, Integer> {
	
}
