package li.bankfrick.informatik.reporting.csdr.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import li.bankfrick.informatik.reporting.csdr.entities.db.excel.Details_1_1;

public interface Details_1_1_Repository extends JpaRepository<Details_1_1, Integer> {
	
}
