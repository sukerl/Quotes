CREATE DATABASE currencies_test default character set utf8 default collate utf8_bin;
GRANT ALL PRIVILEGES ON currencies_test.* TO 'currencies_test_rwx'@'%' IDENTIFIED BY '1Currencies!';
GRANT SELECT, INSERT, UPDATE, DELETE ON  currencies_test.* TO 'currencies_test_rw'@'%' IDENTIFIED BY '1Currencies!';
GRANT SELECT ON currencies_test.* TO 'currencies_test_r'@'%' IDENTIFIED BY '1Currencies!';