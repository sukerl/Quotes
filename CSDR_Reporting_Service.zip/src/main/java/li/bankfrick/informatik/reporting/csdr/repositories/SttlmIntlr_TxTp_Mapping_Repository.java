package li.bankfrick.informatik.reporting.csdr.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import li.bankfrick.informatik.reporting.csdr.entities.db.mapping.SttlmIntlr_TxTp_Mapping;

public interface SttlmIntlr_TxTp_Mapping_Repository extends JpaRepository<SttlmIntlr_TxTp_Mapping, Integer> {
	

}
