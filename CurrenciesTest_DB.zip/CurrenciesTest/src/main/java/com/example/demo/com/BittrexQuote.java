package com.example.demo.com;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BittrexQuote {
	
	BigDecimal PrevDay;
	BigDecimal Last;
	BigDecimal High;
	BigDecimal Low;
	BigDecimal Volume;
	BigDecimal Bid;
	BigDecimal Ask;
	
	public BittrexQuote() {
		super();
	}

	public BigDecimal getPrevDay() {
		return PrevDay;
	}

	public void setPrevDay(BigDecimal prevDay) {
		PrevDay = prevDay;
	}

	public BigDecimal getLast() {
		return Last;
	}

	public void setLast(BigDecimal last) {
		Last = last;
	}

	public BigDecimal getHigh() {
		return High;
	}

	public void setHigh(BigDecimal high) {
		High = high;
	}

	public BigDecimal getLow() {
		return Low;
	}

	public void setLow(BigDecimal low) {
		Low = low;
	}

	public BigDecimal getVolume() {
		return Volume;
	}

	public void setVolume(BigDecimal volume) {
		Volume = volume;
	}

	public BigDecimal getBid() {
		return Bid;
	}

	public void setBid(BigDecimal bid) {
		Bid = bid;
	}

	public BigDecimal getAsk() {
		return Ask;
	}

	public void setAsk(BigDecimal ask) {
		Ask = ask;
	}

	@Override
	public String toString() {
		return "BittrexQuote [PrevDay=" + PrevDay + ", Last=" + Last + ", High=" + High + ", Low=" + Low + ", Volume="
				+ Volume + ", Bid=" + Bid + ", Ask=" + Ask + "]";
	}

}
