package com.example.demo;

import java.math.BigDecimal;
import java.math.MathContext;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.example.demo.com.GenericQuote;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class BittrexController {

	private static final Logger log = LoggerFactory.getLogger(BittrexController.class);

	private final QuoteRepository QRepository;
	public BittrexController(QuoteRepository QRepository) {
		this.QRepository = QRepository;
	}

	@Scheduled(cron = "${bittrex.schedule}")
	public void run() {

		RestTemplateBuilder bittrexRestTemplateBuilder = new RestTemplateBuilder();
		RestTemplate bittrexRestTemplate = bittrexRestTemplateBuilder.build();

		try {
			String jsonString = bittrexRestTemplate.getForObject("https://api.bittrex.com/api/v1.1/public/getmarketsummary?market=btc-tube", String.class);
			//String jsonString = bittrexRestTemplate.getForObject("https://api.bittrex.com/api/v1.1/public/getmarketsummaries", String.class);
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(jsonString);

			JsonNode resultNode = rootNode.path("result");
			if (resultNode.isArray()) {
				for (JsonNode node : resultNode) {

					GenericQuote bittrexQuote = new GenericQuote();

					bittrexQuote.setExchangeName("Bittrex");
					bittrexQuote.setMarketName(node.path("MarketName").asText());
					bittrexQuote.setPrice(BigDecimal.valueOf(node.path("Last").asDouble()));
					bittrexQuote.setHigh(BigDecimal.valueOf(node.path("High").asDouble()));
					bittrexQuote.setLow(BigDecimal.valueOf(node.path("Low").asDouble()));
					bittrexQuote.setVolume(BigDecimal.valueOf(node.path("Volume").asDouble()));
					bittrexQuote.setBid(BigDecimal.valueOf(node.path("Bid").asDouble()));
					bittrexQuote.setAsk(BigDecimal.valueOf(node.path("Ask").asDouble()));
					bittrexQuote.setRequestTimestamp(new Timestamp(System.currentTimeMillis()));

					log.info(bittrexQuote.toString());
					QRepository.save(bittrexQuote);
				}
			}
		} catch (Exception e) {
			log.error(e.toString());
		}
	}
}
